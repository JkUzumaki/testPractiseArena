#include<iostream>

int main()
{
	int ar[4];
	ar[5-3] = 133330;
	std::cout << ar[2] << "\n";
}

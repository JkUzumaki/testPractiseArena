#include<iostream>

int main()
{
	int arr[5]= {1, 2,3};
	
	for(int i = 0; i < 5; i++)
		std::cout << arr[i] << " ";
	std::cout << "\n";
}

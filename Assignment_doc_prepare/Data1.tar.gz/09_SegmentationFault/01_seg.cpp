#include<iostream>
using namespace std;
int main()
{
	int *ptr = NULL;
	cout << "ptr " << *ptr << endl;
}

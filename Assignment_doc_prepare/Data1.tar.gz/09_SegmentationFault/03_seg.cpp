#include<iostream>
using namespace std;
int main()
{
	int arr[1];
	arr[2] = 10;	
}

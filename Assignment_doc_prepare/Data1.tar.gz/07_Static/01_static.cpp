#include<iostream>

int main()
{
	static int val;
	std::cout << "The val is " << val << std::endl;
}

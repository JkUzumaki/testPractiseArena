// UPCASTING
1. It's converting a derived class reference or pointer to a base class.
2. 
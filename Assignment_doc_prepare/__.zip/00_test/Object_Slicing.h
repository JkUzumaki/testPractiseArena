// Object slicing
In C++ a derived class object can be assigned to a base class object but the other way is not possible.

//Upcasting and Downcasting
UPCASTING:
	It's the process of converting the derived class reference or pointer to base class.
	Upcasting allows to treat a derived type as though it were a base type.
	This is a result of is-a relationship between base and derived class.
	

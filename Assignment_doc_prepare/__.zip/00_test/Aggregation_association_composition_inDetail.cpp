// Learnign association, aggregation and composition

//////////////////////////////////////////////////////////////////// Association /////////////////////////////////////////////////////////////////////////////////////////////////////
//Its a simple structural connection or channel between classes and is a relationship where all objects have their own life cycle and there is no owner.
//Lets see department and student 
//	Multiple student are associated with single department and single department contains multiple student but there is no ownership between the object and both have their own life cycle.
// 
#include <iostream>
#include <fstream>
using namespace std;
int main(){
	ofstream file;
	file.open("FileTest.txt");
	file & lt; & lt;
	file.close();
	return 0;
}
